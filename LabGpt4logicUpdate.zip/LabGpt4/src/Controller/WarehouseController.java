package Controller;
import Data.DataSingleton;
import Model.ExportReceipt;
import Model.ImportReceipt;
import Model.Product;
import Model.Receipt;
import java.util.*;

public class WarehouseController {
    private Map<String, ImportReceipt> importReceipts;
    private Map<String, ExportReceipt> exportReceipts;
    private Map<String, Product> products;
    public WarehouseController() {
        this.importReceipts = DataSingleton.getInstance().getImportReceipts();
        this.exportReceipts = DataSingleton.getInstance().getExportReceipts();
        this.products = DataSingleton.getInstance().getProducts();
        
    }
    
    /**
     * tạo list chứa các receips có chứa product dựa vào product code
     * @param productCode code product để lấy receipts
     * @return list các receipts chứa code
     * @throws ProductNotFoundException không tìm thấy receipts chứa product 
     */
    public List<Receipt> getReceiptsByProductCode(String productCode) throws ProductNotFoundException {
        if (productCode == null || productCode.isEmpty()) {
            throw new IllegalArgumentException("Invalid product code.");
        }
        List<Receipt> matchingReceipts = new ArrayList<>();
        for (Receipt receipt : importReceipts.values()) {
            if (receipt instanceof ImportReceipt && receipt.containsProduct(productCode)) {
                matchingReceipts.add(receipt);
            }
        }
        for (Receipt receipt : exportReceipts.values()) {
            if (receipt instanceof ExportReceipt && receipt.containsProduct(productCode)) {
                matchingReceipts.add(receipt);
            }
        }
        if (matchingReceipts.isEmpty()) {
            throw new ProductNotFoundException("No receipts found for product with code: " + productCode);
        }
        return matchingReceipts;
    }
    
    /**
     * tạo list các product bán được nhờ kiểm tra:
     * product không hết hạn
     * số lượng product>0
     * @return list các product bán được
     */
    public List<Product> getProductsForSale() {
        List<Product> productsForSale = new ArrayList<>();
        for (Product product : products.values()) {
            int stock = product.getImportedQuantity() + product.getExportedQuantity();
            if (!product.isExpired() && stock > 0) {
                productsForSale.add(product);
            }
        }
        return productsForSale;
    }
    
    /**
     * tạo list product ít hàng sắp xếp giảm dần dựa vâo kiểm tra:
     * số lượng product <=3
     * @return list product ít hàng
     */
    public List<Product> getLowStockProducts() {
        List<Product> lowStockProducts = new ArrayList<>();
        for (Product product : products.values()) {
            int stock = product.getImportedQuantity() + product.getExportedQuantity();
            if (stock <= 3) {
                lowStockProducts.add(product);
            }
        }
        // Sort by quantity
        Collections.sort(lowStockProducts, Comparator.comparing(product -> 
            product.getImportedQuantity() + product.getExportedQuantity()));
        return lowStockProducts;
    }
    
}
    
    
    

