package View;

import Controller.FlightController;
import Controller.ReservationController;
import Tools.Tool;
import model.Flight;
import model.Passenger;
import model.Reservation;


public class CheckInView {
    FlightController flightController = new FlightController();
    ReservationController reservationController = new ReservationController();
    
    public CheckInView() {
    }
    
    public void start() {
    checkIn();
}
    
    
    public void checkIn() {
        // 1. Prompt for Reservation ID
        if(reservationController.checkEmpty("0 reservation was regerate how can you check in huh? ")) return;
        String reservationId = reservationController.getReservationID();
        Reservation reservation = reservationController.getReservation(reservationId);
        displayBoardingPass(reservation);
        // 2. Display Flight Seating
        Flight flightForReservation = reservation.getFlight();
        flightController.displaySeats(flightForReservation);

        // 3. Seat Selection
        int maxSeats = flightForReservation.getCheckInSeats(); // Assuming this is the total number of seats
        int chosenSeat = Tool.validateIntRange("Choose an available seat by entering its number: ", 1, maxSeats, "Invalid choice. Please select a valid seat number.", false);

        while (flightForReservation.isSeatTaken(chosenSeat)) {
            System.out.println("This seat is already reserved. Please choose another seat.");
            chosenSeat = Tool.validateIntRange("Choose an available seat by entering its number: ", 1, maxSeats, "Invalid choice. Please select a valid seat number.", false);
        }
        flightForReservation.reserveSeat(chosenSeat); // Assuming Flight has a method to mark a seat as reserved

        // 4. Confirmation
        System.out.println("Your seat has been successfully reserved. Your chosen seat number is: " + chosenSeat);
    }
    
    public void displayBoardingPass(Reservation reservation) {
    Passenger passenger = reservation.getPassenger();
    Flight flight = reservation.getFlight();
    
    System.out.println("===================================================");
    System.out.println("                     BOARDING PASS                 ");
    System.out.println("===================================================");
    System.out.println("Passenger Information:");
    System.out.println("---------------------------------------------------");
    System.out.println("Name: " + passenger.getName());
    System.out.println("Contact Info: " + passenger.getContactDetails());
    System.out.println("Reservation ID: " + reservation.getReservationId());
    System.out.println("---------------------------------------------------");
    System.out.println("Flight Information:");
    System.out.println("---------------------------------------------------");
    System.out.println("Flight Number: " + flight.getFlightNumber());
    System.out.println("Departure City: " + flight.getDepartureCity());
    System.out.println("Destination City: " + flight.getDestinationCity());
    System.out.println("Departure Time: " + flight.getDepartureTime());
    System.out.println("Arrival Time: " + flight.getArrivalTime());
    System.out.println("===================================================");
}

}
