package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;


public class Flight {
    private String flightNumber;
    private String departureCity;
    private String destinationCity;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
    private int availablitySeats;
    private int checkInSeats;
    private int totalSeats;
    private Set<Integer> reservedSeats;
    private Map<String, CrewMember> crewAssign;

    public Flight(String flightNumber, String departureCity, String destinationCity, 
                  LocalDateTime departureTime, LocalDateTime arrivalTime, int totalSeats) {
        this.flightNumber = flightNumber;
        this.departureCity = departureCity;
        this.destinationCity = destinationCity;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.totalSeats = totalSeats;
        this.availablitySeats = totalSeats;
        this.checkInSeats = totalSeats;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getDepartureCity() {
        return departureCity;
    }

    public void setDepartureCity(String departureCity) {
        this.departureCity = departureCity;
    }

    public String getDestinationCity() {
        return destinationCity;
    }

    public void setDestinationCity(String destinationCity) {
        this.destinationCity = destinationCity;
    }

    public LocalDateTime getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(LocalDateTime departureTime) {
        this.departureTime = departureTime;
    }

    public LocalDateTime getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(LocalDateTime arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getAvailablitySeats() {
        return availablitySeats;
    }

    public void setAvailablitySeats(int availablitySeats) {
        this.availablitySeats = availablitySeats;
    }

    public int getCheckInSeats() {
        return checkInSeats;
    }

    public void setCheckInSeats(int checkInSeats) {
        this.checkInSeats = checkInSeats;
    }

    public Set<Integer> getReservedSeats() {
        return reservedSeats;
    }

    public void setReservedSeats(Set<Integer> reservedSeats) {
        this.reservedSeats = reservedSeats;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public void setTotalSeats(int totalSeats) {
        this.totalSeats = totalSeats;
    }
    
    public void setCrewAssign(Map<String, CrewMember> crewAssign) {
        this.crewAssign = crewAssign;
    }

    public void assignCrewMember(CrewMember crewMember) {
        this.crewAssign.put(crewMember.getCrewId(), crewMember);
    }

    public void removeCrewMember(String crewMemberId) {
        this.crewAssign.remove(crewMemberId);
    }
    
    public String toStringShowAll() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy HH:mm");
        String formattedDepartureTime = departureTime.format(formatter);
        String formattedArrivalTime = arrivalTime.format(formatter);

        return String.format("| %-10s | %-10s | %-10s | %-20s | %-20s | %-8d |",
                             flightNumber,
                             departureCity,
                             destinationCity,
                             formattedDepartureTime,
                             formattedArrivalTime,
                             availablitySeats);
    }
    
    public boolean isSeatTaken(int seatNumber) {
        return reservedSeats.contains(seatNumber);
    }

    public void reserveSeat(int seatNumber) {
        setCheckInSeats(getCheckInSeats()-1);
        reservedSeats.add(seatNumber);
    }
}