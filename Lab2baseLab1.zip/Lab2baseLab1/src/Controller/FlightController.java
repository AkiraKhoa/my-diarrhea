
package Controller;

import java.util.Map;
import model.Flight;
import Data.DataSingleton;
import Tools.Tool;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


public class FlightController {
    private Map<String, Flight> flights;
    public FlightController() {
        this.flights = DataSingleton.getInstance().getFlight();
    }
    
    public boolean exists(String flightNumber) {
        return flights.containsKey(flightNumber);
    }

    public void add(String flightNumber, String departureCity, String destinationCity, LocalDateTime departureTime, LocalDateTime arrivalTime, int seatNumber) {
        flights.put(flightNumber, new Flight(flightNumber, departureCity, destinationCity, departureTime, arrivalTime, seatNumber));
        System.out.println("Flight added successfully!");
    }
    
    public void update(String flightNumber, String departureCity, String destinationCity, LocalDateTime departureTime, LocalDateTime arrivalTime, Integer seatNumber){
        Flight flightupdated = flights.get(flightNumber);
        if(!departureCity.isEmpty()) flightupdated.setDepartureCity(departureCity);
        if(!destinationCity.isEmpty()) flightupdated.setDestinationCity(destinationCity);
        if(departureTime != null) flightupdated.setArrivalTime(arrivalTime);
        if(arrivalTime != null) flightupdated.setArrivalTime(arrivalTime);
        if(seatNumber != null) flightupdated.setTotalSeats(seatNumber);
        System.out.println("Flight updated successfully");
    }
    
    public boolean checkEmpty(String errorMessage){
        if (flights.isEmpty()) {
            System.out.println(errorMessage);
            return true;
        } else return false;
    }
    
    public Flight getFlight(String flightNumber) {
        return flights.get(flightNumber);
    }
    
    public void remove(String flightNumber){
        flights.remove(flightNumber);
        System.out.println("Flight deleted successfully!");
    }
    
    /**
     * Searches for flights based on the given parameters: departure location, arrival location, and desired date.
     *
     * @param departureLocation - the departure city or location
     * @param arrivalLocation   - the arrival city or location
     * @param desiredDate       - the desired date of the flight
     * @return a list of flights matching the search criteria
     */
    public List<Flight> searchFlights(String departureLocation, String arrivalLocation, LocalDateTime desiredDate) {
        List<Flight> matchingFlights = new ArrayList<>();
        for (Flight flight : flights.values()) {
            if (flight.getDepartureCity().equalsIgnoreCase(departureLocation) &&
                flight.getDestinationCity().equalsIgnoreCase(arrivalLocation) &&
                flight.getDepartureTime().toLocalDate().equals(desiredDate)) {
                matchingFlights.add(flight);
            }
        }
        if(matchingFlights.isEmpty()) {
            System.out.println("Sorry, no flights match your criteria.");
        }

        return matchingFlights;
    }
    
    

    
    public Flight chooseFitFlight(String departureLocation, String arrivalLocation, LocalDateTime desiredDates){
        List<Flight> matchingFlights = searchFlights(departureLocation, arrivalLocation, desiredDates);
        if (matchingFlights.isEmpty()) {
            System.out.println("No matching flights found.");
            return null;
        }
        while (true){
           int choice = Tool.validateIntRange("Select a flight by its number: ", 1, matchingFlights.size(), "Invalid choice. Please select a number from the displayed list.", false); 
           Flight selectedFlight = matchingFlights.get(choice - 1); 
           if (selectedFlight.getAvailablitySeats() <= 0) {
            System.out.println("Unfortunately, the selected flight is fully booked.");
            if (!Tool.validateYesOrNo("would you like to choose another flight(y/n): ", "Failed to choose flights")) {
                return null;
            }
            else {
                matchingFlights.remove(selectedFlight);
                continue;
            }
        }
            selectedFlight.setAvailablitySeats(selectedFlight.getAvailablitySeats() - 1);
            System.out.println("You've selected flight number: " + selectedFlight.getFlightNumber());
            return selectedFlight;
        }
    }
    
    
    public void displaySeats(Flight flight) {
        // Constants for the seating
        final int SEATS_PER_ROW = 6;
        final int SEATS_BEFORE_AISLE = 3;

        int totalSeats = flight.getAvailablitySeats()+ flight.getCheckInSeats();
        int numRows = (int) Math.ceil((double) totalSeats / SEATS_PER_ROW);
        int exitRow = numRows / 2;

        int seatCounter = 1;  // Counter to track the current seat number

        for (int row = 1; row <= numRows; row++) {
            if (row == exitRow) {
                System.out.println("EXIT\t\t\t\t\t\tEXIT");
            }

            // Display the seat row
            for (int seat = 1; seat <= SEATS_PER_ROW; seat++) {
                if (seat == SEATS_BEFORE_AISLE + 1) {
                    System.out.print("\t"); // space for the aisle
                }

                if (flight.isSeatTaken(seatCounter)) {
                    System.out.printf("|  X  |");
                } else {
                    System.out.printf("| %3d |", seatCounter);
                    seatCounter++;
                }
            }
            System.out.println(); 

            // Only display the row separator for non-last rows
            if (row != numRows) {
                System.out.println("+-----++-----++-----+\t+-----++-----++-----+");
            }
        }
    }
    
    public Integer getSeatNumber(String flightNumber){
        Flight currentFlight = flights.get(flightNumber);
        Integer seatNumber;
        while (true){
        seatNumber = Tool.validateIntRange("Number of seat(1-120) or enter to skip this one: ", 1, 120, "can only handle 120 seat", true);
        if (seatNumber<currentFlight.getAvailablitySeats() || seatNumber<currentFlight.getCheckInSeats()) 
            System.out.println("can't lower than " + currentFlight.getAvailablitySeats() + " and " + currentFlight.getCheckInSeats());
        else break;
        } 
        return seatNumber;
    }
    
    public String getFlightNumber(String prompt, boolean shouldExist) {
    while (true) {
        String flightNumber = Tool.validateCode(prompt, "Flight number must follow Fxyzt", false);
        boolean exists = exists(flightNumber); // Assuming exists() checks if the flight number exists

        if (shouldExist && !exists) {
            System.out.println("Flight number doesn't exist. Please try again.");
            continue;
        } else if (!shouldExist && exists) {
            System.out.println("Flight number already exists. Please try again.");
            continue;
        }
        return flightNumber;
    }
}

}
