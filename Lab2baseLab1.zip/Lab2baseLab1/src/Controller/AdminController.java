package Controller;

import java.util.List;
import model.Admin;
import Data.DataSingleton;

public class AdminController {
    private List<Admin> admins;

    public AdminController() {
        this.admins = DataSingleton.getInstance().getAdmin();
    }
    
    public boolean validateAdminCredentials(String username, String password) {
        for (Admin admin : admins) {
            if (admin.getUsername().equals(username) && admin.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }
    
    

}
