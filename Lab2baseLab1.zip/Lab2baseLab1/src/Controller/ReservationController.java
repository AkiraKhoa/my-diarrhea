package Controller;

import java.util.Map;
import model.Reservation;
import Data.DataSingleton;
import Tools.Tool;

public class ReservationController {
    private Map<String, Reservation> reservations;

    public ReservationController() {
        this.reservations = DataSingleton.getInstance().getReservation();
    }
    
    public void add(Reservation reservation) {
        if (reservation == null) {
            throw new IllegalArgumentException("Reservation cannot be null");
        }
        reservations.put(reservation.getReservationId(), reservation);
        System.out.println("Reservation successfully made! Your reservation ID is: " + reservation.getReservationId());
    }
    
    public String getReservationID (){
        while(true){
            String input = Tool.validateReservationID("Enter your reservation ID: ", "Invalid input. Please try again.");
            if(reservations.containsKey(input)) return input;
            System.out.println("that Reservation ID never generated");
        }
    }
    
    public Reservation getReservation(String reservationId) {
        return reservations.get(reservationId);
    }
    
    public boolean checkEmpty(String errorMessage){
        if (reservations.isEmpty()) {
            System.out.println(errorMessage);
            return true;
        } else return false;
    }

    // Add methods to interact with reservations as needed
}
