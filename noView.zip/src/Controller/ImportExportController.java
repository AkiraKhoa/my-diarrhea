package Controller;

import Model.WarehouseManager;
import Model.ImportReceipt;
import Model.ExportReceipt;

public class ImportExportController {
    private WarehouseManager warehouseManager;

    public ImportExportController() {
        warehouseManager = new WarehouseManager();
    }

    public void createImportReceipt(String code) {
        ImportReceipt newImportReceipt = new ImportReceipt(code);
        warehouseManager.addImportReceipt(newImportReceipt);
        System.out.println("Import receipt created successfully.");
    }

    public void createExportReceipt(String code) {
        ExportReceipt newExportReceipt = new ExportReceipt(code);
        warehouseManager.addExportReceipt(newExportReceipt);
        System.out.println("Export receipt created successfully.");
    }

    public void addItemToImportReceipt(String receiptCode, String productCode, int quantity) {
        if (warehouseManager.addItemToImportReceipt(receiptCode, productCode, quantity)) {
            System.out.println("Item added to import receipt.");
        } else {
            System.out.println("Failed to add item to import receipt.");
        }
    }

    public void addItemToExportReceipt(String receiptCode, String productCode, int quantity) {
        if (warehouseManager.addItemToExportReceipt(receiptCode, productCode, quantity)) {
            System.out.println("Item added to export receipt.");
        } else {
            System.out.println("Failed to add item to export receipt.");
        }
    }

    // Additional methods can be added here
}
