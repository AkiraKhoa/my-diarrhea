package Controller;
import Model.ExportReceipt;
import Model.ImportReceipt;
import Model.Product;
import Model.Receipt;
import java.util.*;

import Model.WarehouseManager;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class WarehouseController {
    private Map<String, ImportReceipt> importReceipts;
    private Map<String, ExportReceipt> exportReceipts;
    private Map<String, Product> products;
    public WarehouseController() {
        this.importReceipts = new HashMap<>();
        this.exportReceipts = new HashMap<>();
        this.products = new HashMap<>();
    }
    
    public boolean createImportReceipt(ImportReceipt receipt) {
        if (receipt == null || receipt.getCode() == null) {
        throw new IllegalArgumentException("Invalid receipt or receipt code.");
        }
        if (importReceipts.containsKey(receipt.getCode())) {
            return false; // Receipt already exists
        }
        importReceipts.put(receipt.getCode(), receipt);
        return true;
    }
    
    public boolean createExportReceipt(ExportReceipt receipt) {
        if (receipt == null || receipt.getCode() == null) {
        throw new IllegalArgumentException("Invalid receipt or receipt code.");
        }
        if (exportReceipts.containsKey(receipt.getCode())) {
            return false; // Receipt already exists
        }
        exportReceipts.put(receipt.getCode(), receipt);
        return true;
    }

    public List<Receipt> getReceiptsByProductCode(String productCode) throws ProductController.ProductNotFoundException {
        if (productCode == null || productCode.isEmpty()) {
        throw new IllegalArgumentException("Invalid product code.");
    }
        List<Receipt> receipts = new ArrayList<>();
        for (ImportReceipt receipt : importReceipts.values()) {
            if (receipt.containsProduct(productCode)) {
                receipts.add(receipt);
            }
        }
        for (ExportReceipt receipt : exportReceipts.values()) {
            if (receipt.containsProduct(productCode)) {
                receipts.add(receipt);
            }
        }
        
        return receipts;
    }
    public void addImportReceipt(ImportReceipt receipt) {
    importReceipts.put(receipt.getCode(), receipt);
    }

    public void addExportReceipt(ExportReceipt receipt) {
        exportReceipts.put(receipt.getCode(), receipt);
    }

    public boolean addItemToImportReceipt(String receiptCode, String productCode, int quantity) {
        ImportReceipt receipt = importReceipts.get(receiptCode);
        if (receipt != null) {
            receipt.addProduct(productCode, quantity);
            return true;
        }
        return false;
    }

    public boolean addItemToExportReceipt(String receiptCode, String productCode, int quantity) {
        ExportReceipt receipt = exportReceipts.get(receiptCode);
        if (receipt != null) {
            receipt.addProduct(productCode, quantity);
            return true;
        }
        return false;
    }
    public int getImportedQuantityForProduct(String productCode) {
        if (productCode == null || productCode.isEmpty()) {
        throw new IllegalArgumentException("Invalid product code.");
    }
        int importedQuantity = 0;
        for (ImportReceipt importReceipt : importReceipts.values()) {
            Map<String, Integer> products = importReceipt.getProducts();
            if (products.containsKey(productCode)) {
                importedQuantity += products.get(productCode);
            }
        }
        return importedQuantity;
    }
    
    // Method to get the exported quantity of a specific product
    public int getExportedQuantityForProduct(String productCode) {
        if (productCode == null || productCode.isEmpty()) {
        throw new IllegalArgumentException("Invalid product code.");
    }
        int exportedQuantity = 0;
        for (ExportReceipt exportReceipt : exportReceipts.values()) {
            Map<String, Integer> products = exportReceipt.getProducts();
            if (products.containsKey(productCode)) {
                exportedQuantity += products.get(productCode);
            }
        }
        return exportedQuantity;
    }
    
    public int getStockForProduct(String productCode) {
        int importedQuantity = getImportedQuantityForProduct(productCode);
        int exportedQuantity = getExportedQuantityForProduct(productCode);
        return importedQuantity - exportedQuantity;
    }
    
    public List<Product> getProductsForSale() {
    List<Product> productsForSale = new ArrayList<>();
    for (Product product : products.values()) {
        int stock = this.getStockForProduct(product.getProductCode());
        if (!product.isExpired() && stock > 0) {
            productsForSale.add(product);
        }
    }
    return productsForSale;
}
    // Method for checking inventory
    public void checkInventory(String productCode) {
        int stock = this.getStockForProduct(productCode);
        System.out.println("Current stock for product " + productCode + ": " + stock);
    }
    
    public List<Product> getLowStockProducts() {
    List<Product> lowStockProducts = new ArrayList<>();
    for (Product product : products.values()) {
        int stock = this.getStockForProduct(product.getProductCode());
        if (stock <= 3) {
            lowStockProducts.add(product);
        }
    }
    // Sort by quantity
    Collections.sort(lowStockProducts, Comparator.comparing(product -> 
        this.getStockForProduct(product.getProductCode())));
    return lowStockProducts;
}
    // Method to save warehouse data to file
    public boolean saveDataToFile(String fileName) {
    if (fileName == null || fileName.isEmpty()) {
        throw new IllegalArgumentException("Invalid file name.");
    }
    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
        oos.writeObject(importReceipts);
        oos.writeObject(exportReceipts);
        return true;
    } catch (IOException e) {
        e.printStackTrace();
        // Consider logging
        return false;
    }
}

    // Method to load warehouse data from file
    public boolean loadDataFromFile(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
        throw new IllegalArgumentException("Invalid file name.");
    }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            importReceipts = (Map<String, ImportReceipt>) (List<Receipt>) ois.readObject();
            exportReceipts = (Map<String, ExportReceipt>) (List<Receipt>) ois.readObject();
            return true;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}
    
    
    

