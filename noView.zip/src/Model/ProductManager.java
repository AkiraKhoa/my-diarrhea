/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class ProductManager {
    private Map<String, Product> products;

    public ProductManager() {
        this.products = new HashMap<>();
    }

    // Method to add a product
    public void addProduct(String code, String name, String category, String manufactureDateStr, String expiryDateStr, double price) {
    if (code.isEmpty() || name.isEmpty() || category.isEmpty() || manufactureDateStr.isEmpty() || expiryDateStr.isEmpty()) {
        System.out.println("All fields must be filled!");
        return;
    }

    if (products.containsKey(code)) {
        System.out.println("Product code already exists!");
        return;
    }

    if (price < 0) {
        System.out.println("You can't give customer money for buying something :(((");
        return;
    }

    try {
        LocalDate manufactureDate = LocalDate.parse(manufactureDateStr);
        LocalDate expiryDate = LocalDate.parse(expiryDateStr);

        if (manufactureDate.isAfter(expiryDate)) {
            System.out.println("Manufacturing date cannot be after expiration date!");
            return;
        }

        products.put(code, new Product(code, name, category, manufactureDate, expiryDate, price)); 
    } catch (DateTimeParseException e) {
        System.out.println("This is the right format for inputting a date: yyyy-mm-dd. Make sure the date actually exists!");
    }
    System.out.println("Product added successfully!");
}
    



    // Method to update a product
   public void updateProduct(String code, String newName, String newCategory, String newManufactureDateStr, String newExpiryDateStr, Double newPrice) {
   if (!products.containsKey(code)) {
        System.out.println("Product code does not exist!");
        return;
    }

    Product productToUpdate = products.get(code);

    if (!newName.isEmpty()) {
        productToUpdate.setProductName(newName);
    }

    if (!newCategory.isEmpty()) {
        productToUpdate.setCategory(newCategory);
    }

    if (newPrice != null && newPrice >= 0) {
        productToUpdate.setPrice(newPrice);
    } else if (newPrice != null && newPrice < 0) {
        System.out.println("You can't give customer money for buying something :(((");
    }

    try {
        if (!newManufactureDateStr.isEmpty() && !newExpiryDateStr.isEmpty()) {
            LocalDate newManufactureDate = LocalDate.parse(newManufactureDateStr);
            LocalDate newExpiryDate = LocalDate.parse(newExpiryDateStr);

            if (newManufactureDate.isAfter(newExpiryDate)) {
                System.out.println("Manufacturing date cannot be after expiration date!");
                return;
            }

            productToUpdate.setManufacturingDate(newManufactureDate);
            productToUpdate.setExpirationDate(newExpiryDate);
        }
    } catch (DateTimeParseException e) {
        System.out.println("This is the right format for inputting a date: yyyy-mm-dd. Make sure the date actually exists!");
    }

    System.out.println("Product updated successfully!");
}

    // Method to delete a product
    public boolean deleteProduct(String productCode) {
    if (!products.containsKey(productCode)) {
        System.out.println("Product code does not exist!");
        return false;
    }
    products.remove(productCode);
    System.out.println("Product deleted successfully!");
    return true;
}

    public boolean isUniqueCode(String code) {
        return !products.containsKey(code);
    }
    
    public Product getProductByCode(String code) throws ProductNotFoundException {
    if (!products.containsKey(code)) {
        throw new ProductNotFoundException("Product with code " + code + " not found.");
    }
    return products.get(code);
}

    public Map<String, Product> getAllProducts() {
        return products;
    }

    // Method to show all products
    public List<Product> showAllProducts() {
        return new ArrayList<>(products.values());
    }

    // Method to get expired products
    public List<Product> getExpiredProducts() throws ProductNotFoundException {
    List<Product> expiredProducts = new ArrayList<>();
    for (Product product : products.values()) {
        if (product.isExpired()) {
            expiredProducts.add(product);
        }
    }
    if (expiredProducts.isEmpty()) {
        throw new ProductNotFoundException("No expired products found.");
    }
    return expiredProducts;
}

    // Method to save products to file
    public boolean saveProductsToFile(String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(products);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to load products from file
    public boolean loadProductsFromFile(String fileName) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            products = (HashMap<String, Product>) ois.readObject();
            return true;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Additional methods can be added here

    
}
