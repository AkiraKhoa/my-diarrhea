package View;

import Controller.ImportExportController;
import Controller.ProductController;
import Controller.ProductNotFoundException;
import Controller.WarehouseController;
import Model.Product;
import Tools.Tool;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




public class WarehouseView {
    private final ImportExportController importExportController;
    private Map<String, Product> products;
    private final ProductController productController;
    private final WarehouseController warehouseController;




    public WarehouseView(ImportExportController importExportController, ProductController productController, WarehouseController warehouseController) {
        this.importExportController = importExportController;
        this.productController = productController;
        this.warehouseController = warehouseController;
    }

    public void createAndManageImportReceipt() {
    try {
        String receiptCode = importExportController.generateImportCode();
        System.out.println("Import receipt created successfully. Receipt code: " + receiptCode);

        while (true) {
            String productCode = Tool.validateExistInMap("Enter the product code to add: ", products, "Product code does not exist!");
            int quantity = Tool.validateInt("Enter the quantity: ", "Invalid quantity.");
            
            boolean itemAdded = importExportController.addItemToImportReceipt(receiptCode, productCode, quantity);
            if (itemAdded) {
                System.out.println("Item added to import receipt and product quantity updated.");
            } else {
                System.out.println("Failed to add item to import receipt.");
            }

            String continueChoice = Tool.validateString("Would you like to add more products? (yes/no): ", "Invalid input.");
            if ("no".equalsIgnoreCase(continueChoice)) {
                break;
            }
        }
        System.out.println("Import receipt confirmed.");
    } catch (ProductNotFoundException e) {
        System.out.println(e.getMessage());
    }
}
    public void createAndManageExportReceipt() {
        try {
            String code = importExportController.createExportReceipt();
            System.out.println("Export receipt created successfully. Receipt code: " + code);
            
            while (true) {
                String productCode = Tool.validateExistInMap("Enter the product code to add: ", products, "Product code does not exist!");
                int quantity = Tool.validateInt("Enter the quantity: ", "Invalid quantity.");
                
                if (importExportController.addItemToExportReceipt(code, productCode, quantity)) {
                    System.out.println("Item added to export receipt and product quantity updated.");
                } else {
                    System.out.println("Insufficient quantity in stock.");
                }

                String continueChoice = Tool.validateString("Would you like to add more products? (yes/no): ", "Invalid input.");
                if ("no".equalsIgnoreCase(continueChoice)) {
                    break;
                }
            }
            
            System.out.println("Export receipt confirmed.");
        } catch (ProductNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void displayExpiredProducts() {
        try {
            List<Product> expiredProducts = productController.getExpiredProducts();
            
            // Print header
            System.out.println("-----------------------------------------------------------------------------------------");
            System.out.println("                              List of Expired Products                                   ");
            System.out.println("-----------------------------------------------------------------------------------------");
            System.out.format("| %-8s | %-20s | %-12s | %-12s | %-10s |", "CODE", "NAME", "MANUFACTURE", "EXPIRE", "QUANTITY");
            System.out.println();
            System.out.println("-----------------------------------------------------------------------------------------");

            // Print products
            for (Product product : expiredProducts) {
                System.out.println(product.toString());  // Use existing toString() method
            }
            
            System.out.println("-----------------------------------------------------------------------------------------");

        } catch (ProductNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void displayProductsForSale() {
        List<Product> productsForSale = warehouseController.getProductsForSale();
        if (!productsForSale.isEmpty()) {
            // Print header
            System.out.println("-----------------------------------------------------------------------------------------");
            System.out.println("                              List of Products for Sale                                  ");
            System.out.println("-----------------------------------------------------------------------------------------");
            System.out.format("| %-8s | %-20s | %-12s | %-12s | %-10s |", "CODE", "NAME", "MANUFACTURE", "EXPIRE", "QUANTITY");
            System.out.println();
            System.out.println("-----------------------------------------------------------------------------------------");

            // Print products
            for (Product product : productsForSale) {
                System.out.println(product.toString());  // Using existing toString() method
            }
            
            System.out.println("-----------------------------------------------------------------------------------------");
        } else {
            System.out.println("No products available for sale.");
        }

        // Return to the main screen (if you have one)
    }
    
    public void displayLowStockProducts() {
        List<Product> lowStockProducts = warehouseController.getLowStockProducts();
        if (!lowStockProducts.isEmpty()) {
            // Print header
            System.out.println("-----------------------------------------------------------------------------------------");
            System.out.println("                              List of Low-Stock Products                                 ");
            System.out.println("-----------------------------------------------------------------------------------------");
            System.out.format("| %-8s | %-20s | %-12s | %-12s | %-10s |", "CODE", "NAME", "MANUFACTURE", "EXPIRE", "QUANTITY");
            System.out.println();
            System.out.println("-----------------------------------------------------------------------------------------");

            // Print products
            for (Product product : lowStockProducts) {
                System.out.println(product.toString());  // Using existing toString() method
            }
            
            System.out.println("-----------------------------------------------------------------------------------------");
        } else {
            System.out.println("No low-stock products found.");
        }
        // Return to the main screen (if you have one)
    }
}
