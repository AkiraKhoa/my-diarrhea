
package Model;

public class ExportReceipt extends Receipt {
    
    public ExportReceipt(String code) {
        super(code);
    }
    
}
