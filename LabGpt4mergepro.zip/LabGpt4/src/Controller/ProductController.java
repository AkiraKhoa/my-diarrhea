package Controller;

import Model.Product;
import Model.ProductManager;
import java.util.List;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;


public class ProductController {
    private ProductManager productManager;

    public ProductController() {
        productManager = new ProductManager();
    }

    public List<Product> getAllProducts() {
        List<Product> allProducts = (List<Product>) productManager.getAllProducts();
        if (allProducts.isEmpty()) {
            System.out.println("No products are available.");
        }
        return allProducts;
    }


    // Additional methods can be added here
}
