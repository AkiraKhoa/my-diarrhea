package Controller;
import Model.ExportReceipt;
import Model.ImportReceipt;
import java.util.*;

import Model.WarehouseManager;

public class WarehouseController {
    private WarehouseManager warehouseManager;
    private List<ImportReceipt> importReceipts;
    private List<ExportReceipt> exportReceipts;
    
    public WarehouseController() {
        warehouseManager = new WarehouseManager();
    }
    
    // Method for checking inventory
    public void checkInventory(String productCode) {
        int stock = warehouseManager.getStockForProduct(productCode);
        System.out.println("Current stock for product " + productCode + ": " + stock);
    }
    
    
    // Additional methods can be added here
}
