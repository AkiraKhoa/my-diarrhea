
package Tools;
import Controller.ProductController;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.time.format.DateTimeFormatter;

public class Tool {
    private static Scanner scanner = new Scanner(System.in);
    private static DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("d/M/yyyy");
    
    /**
     * check người dùng nhập đúng category 
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @return 0 hoặc 1 hoặc null cho update
     */
    public static Integer validateCategoryInputUpdate(String prompt) {
    while (true) {
        System.out.print(prompt);
        String input = scanner.nextLine();

        if (input.isEmpty()) {
            return null;
        }

        if ("0".equals(input) || "1".equals(input)) {
            return Integer.parseInt(input);
        }

        System.out.println("Invalid category. Please enter 0 for daily or 1 for longshelf.");
    }
}
    /**
     * check người dùng nhập đúng ngày hết hạn
     * @param prompt yêu cầu user nhập ngày hết hạn
     * @param manufactureDate ngày sản xuất
     * @return date sau khi đã thỏa điều kiện
     */
    public static LocalDate validateExpiryForLongShelf(String prompt, LocalDate manufactureDate) {
        return validateDateAfter(prompt, manufactureDate, "Expiry date must be at least 7 days after manufacturing date.");
    }

    /**
     * check ngày hết hạn có sau ngày sản xuất 7 ngày không
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param afterThisDate ngày sản xuất 
     * @param errorMessage thông báo lỗi
     * @return 
     */
    public static LocalDate validateDateAfterUpdate(String prompt, LocalDate afterThisDate, String errorMessage) {
        LocalDate date;
        while (true) {
            date = Tool.validateLocalDateUpdate(prompt, "Invalid date format. Please enter again.");
            if (date == null || date.isAfter(afterThisDate.plusDays(7))) {
                return date;
            }
            System.out.println(errorMessage);
        }
    }
    
    /**
     * check valid ngày hết hạn được dùng cho LongShelf category
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param manufactureDate ngày sản xuất
     * @return 
     */
    public static LocalDate validateExpiryForLongShelfSkip(String prompt, LocalDate manufactureDate) {
        return validateDateAfterUpdate(prompt, manufactureDate, "Expiry date must be at least 7 days after manufacturing date.");
    }


    
    
    //TAKE CODE, NAME, PRICE, QUANTITY INFO
    /**
     * check user nhập code chỉ có số và chữ
     * @param prompt thông báo user nhập thông tin cần thiết
     * @param errorMessage thông báo lỗi nếu không đúng pattern 
     * @return code đã được thông qua
     */
    public static String validateCode(String prompt, String errorMessage) {
        String input;
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (Pattern.matches("[a-zA-Z0-9]+", input)) {
                break;
            }
            System.out.println(errorMessage);
        }
        return input;
        }
    
    /**
     * check user nhập chuỗi chỉ có số và chữ và dấu cách
     * @param prompt thông báo user nhập thông tin cần thiết
     * @param errorMessage thông báo lỗi nếu không đúng pattern 
     * @return chuỗi đã được thông qua
     */
    public static String validateAlphanumericString(String prompt, String errorMessage) {
        String input;
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (!input.isEmpty() && Pattern.matches("[a-zA-Z0-9 ]+", input)) {
                break;
            }
            System.out.println(errorMessage);
        }
        return input;
    }
    
    /**
     * check user nhập số thập phân không âm
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param formatErrorMessage báo nhập sai format
     * @param negativeErrorMessage báo nhập số âm
     * @return số thập phân đã được thông qua
     */
    public static double validateDouble(String prompt, String formatErrorMessage, String negativeErrorMessage) {
        double number;
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                number = Double.parseDouble(input);
                if (number >= 0) {
                    break;
                } else {
                    System.out.println(negativeErrorMessage);
                }
            } catch (NumberFormatException e) {
                System.out.println(formatErrorMessage);
            }
        }
        return number;
    }
    
    /**
     * check 1 int ko âm 
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param errorMessage khi sai format
     * @return int đã được thông qua
     */
    public static int validateInt(String prompt, String errorMessage) {
        int number;
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                number = Integer.parseInt(input);
                if (number > 0) {
                    break;
                } else {
                    System.out.println("Number should be greater than 0.");
                }
            } catch (NumberFormatException e) {
                System.out.println(errorMessage);
            }
        }
        return number;
    }
    //=================================================================================

    //UPDATE PRODUCT FR FR
    /**
     * check chuỗi là null hoặc chỉ gồm số và chữ và space
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param errorMessage sai format 
     * @return null hoặc chuỗi đã được thông qua
     */
    public static String validateAlphanumericStringUpdate(String prompt, String errorMessage) {
        String input;
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if(input.isEmpty()) return null;
            else if (Pattern.matches("[a-zA-Z0-9 ]+", input)) {
                break;
            }
            else System.out.println(errorMessage);
        }
        return input;
    }
    
    /**
     * check 1 số thập thân được nhập vào có null hoặc không âm 
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param errorMessage báo lỗi nếu sai format
     * @param negativeMessage báo lỗi nếu âm
     * @return null hoặc double đã được thông qua
     */
    public static Double validateDoubleUpdate(String prompt, String errorMessage, String negativeMessage) {
    while (true) {
        System.out.print(prompt);
        String input = scanner.nextLine().trim();
        if (input.isEmpty()) {
            return null;
        }
        try {
            double value = Double.parseDouble(input);
            if (value < 0) {
                System.out.println(negativeMessage);
            } else {
                return value;
            }
        } catch (NumberFormatException e) {
            System.out.println(errorMessage);
        }
    }
}
    /**
     * check 1 date được nhập vào có đúng format không
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param errorMessage báo lỗi
     * @return LocalDate null hoặc ngày được thông qua
     */
    public static LocalDate validateLocalDateUpdate(String prompt, String errorMessage) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) {
                return null;
            }
            try {
                return LocalDate.parse(input, formatter);
            } catch (DateTimeParseException e) {
                System.out.println(errorMessage + " (" + e.getMessage() + ")");
            }
        }
    }
    
    /**
     * check user nhập ngày sản xuất là null hoặc ngày sản xuất không quá thời gian thực
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @return null hoặc date đã được thông qua
     */
    public static LocalDate validateManufacturingDateSkip(String prompt) {
        LocalDate date;
        while (true) {
            date = Tool.validateLocalDateUpdate(prompt, "Invalid date format. Please enter again.");
            if (date == null || !date.isAfter(LocalDate.now())) {
                return date;
            }
            System.out.println("Manufacture date cannot be in the future.");
        }
    }
    //==============================================================================
    
    //DATE VALID
    
    /**
     * 
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param errorMessage
     * @return 
     */
    public static LocalDate validateLocalDate(String prompt, String errorMessage) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
        LocalDate date;
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                date = LocalDate.parse(input, formatter);
                break;
            } catch (DateTimeParseException e) {
                System.out.println(errorMessage + " (" + e.getMessage() + ")");  // Adding exception message
            }
        }
        return date;
    }
    
    /**
     * 
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param errorMessage
     * @return 
     */
    public static LocalDate validateNotFutureDate(String prompt, String errorMessage) {
        LocalDate date;
        while (true) {
            date = validateLocalDate(prompt, "Invalid date format. Please enter again.");
            if (!date.isAfter(LocalDate.now())) {
                break;
            }
            System.out.println(errorMessage);
        }
        return date;
    }
    
    /**
     * 
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param afterThisDate 
     * @param errorMessage
     * @return 
     */
    public static LocalDate validateDateAfter(String prompt, LocalDate afterThisDate, String errorMessage) {
        LocalDate date;
        while (true) {
            date = validateLocalDate(prompt, "Invalid date format. Please enter again.");
            if (date.isAfter(afterThisDate.plusDays(7))) {
                break;
            }
            System.out.println(errorMessage);
        }
        return date;
    }
    
    
    //========================================================================================================
    /**
     * check user có nhập 1 số tồn tại trong 1 hashmap được cho hay không
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param map hashmap để kiểm tra code có tồn tại trong đó không
     * @param errorMessage báo lỗi nếu không tồn tại
     * @return 
     */
    public static String validateExistProductInMap(String prompt, String errorMessage) {
        String input;
        ProductController productController = new ProductController();
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (productController.getProducts().containsKey(input)) {
                break;
            }
            System.out.println(errorMessage);
        }
        return input;
    }
    
    //CONTROL INPUT
    
    /**
     * check user nhập y hoặc n cho yes hoặc no
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @return true nếu input là y, false nếu bằng n
     */
    public static boolean validateYesOrNo(String prompt) {
        String input;
        while (true) {
            System.out.print(prompt + " (y/n): ");
            input = scanner.nextLine().trim().toLowerCase();
            if ("y".equals(input) || "n".equals(input)) {
                break;
            }
            System.out.println("Invalid input. Enter 'y' for yes and 'n' for no.");
        }
        return "y".equals(input);
    }
    
    /**
     * check user nhập số trong khoảng cho phép
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param min số nhỏ nhất được nhận
     * @param max số lớn nhất được nhận
     * @param errorMessage báo lỗi nhập số ngoài khoảng
     * @return int đã được thông qua
     */
    public static int validateIntRange(String prompt, int min, int max, String errorMessage) {
        int input;
        while (true) {
            System.out.print(prompt);
            try {
                input = Integer.parseInt(scanner.nextLine());
                if (input >= min && input <= max) {
                    return input;
                } else {
                    System.out.println(errorMessage);
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }
    //===========================================================================================
    //TÍNH NĂNG THỜI ĐẠI MỚI
    public static String validateAlphanumericStringTest(String prompt, String errorMessage, boolean allowEmpty) {
        String input;
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();

            if (input.isEmpty() && allowEmpty) {
                return null;
            } else if (!input.isEmpty() && Pattern.matches("[a-zA-Z0-9 ]+", input)) {
                break;
            }
            System.out.println(errorMessage);
        }
        return input;
    }

    public static Double validateDoubleTest(String prompt, String formatErrorMessage, String negativeErrorMessage, boolean b) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            if (input.isEmpty() && b) {
                return null;
            }

            try {
                double number = Double.parseDouble(input);
                if (number >= 0) {
                    return number;
                } else {
                    System.out.println(negativeErrorMessage);
                }
            } catch (NumberFormatException e) {
                System.out.println(formatErrorMessage);
            }
        }    
    }
    
    public static LocalDate validateLocalDateTest(String prompt, String errorMessage, boolean allowEmpty) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            if (input.isEmpty() && allowEmpty) {
                return null;
            }

            try {
                return LocalDate.parse(input, formatter);
            } catch (DateTimeParseException e) {
                System.out.println(errorMessage + " (" + e.getMessage() + ")");
            }
        }
    }
    
    public static LocalDate validateNotFutureDateTest(String prompt, String errorMessage, boolean allowEmpty) {
        LocalDate date;
        while (true) {
            date = validateLocalDateTest(prompt, "Invalid date format. Please enter again.", allowEmpty);
            if (date == null || !date.isAfter(LocalDate.now())) {
                return date;
            }
            System.out.println(errorMessage);
        }
    }
    
    public static LocalDate validateDateAfterTest(String prompt, LocalDate afterThisDate, String errorMessage, boolean allowEmpty) {
    LocalDate date;
    while (true) {
        date = validateLocalDateTest(prompt, "Invalid date format. Please enter again.", allowEmpty);
        if (date == null || date.isAfter(afterThisDate.plusDays(7))) {
            return date;
        }
        System.out.println(errorMessage);
    }
}



}
