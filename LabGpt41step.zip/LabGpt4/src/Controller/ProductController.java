package Controller;

import Data.DataSingleton;
import Model.Product;
import Model.Receipt;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.time.LocalDate;
import java.util.Iterator;



public class ProductController {
    private Map<String, Product> products;
    private String pathFile;
    public ProductController() {
        this.products = DataSingleton.getInstance().getProducts();
        this.pathFile = "";
    }
    
    public Map<String, Product> getProducts() {
        if (products == null) {
            products = DataSingleton.getInstance().getProducts();
        }
        return products;
    }


    /**
    * Thêm product vào hashmap products
    * @param category Loại sản phẩm "Daily" hoặc "L.shelf".
    * @return true if the product was added successfully, false if a product with the same code already exists.
    * @return true nếu thêm thành công.
    */
    public boolean addProduct(String code, String name, String category, LocalDate manufactureDate, LocalDate expiryDate, double price) {
        products.put(code, new Product(code, name, category, manufactureDate, expiryDate, price));
        return true;
    }
    
    /**
    * Set lại info của product.
    * Những info có thể sửa:
    * - Product name
    * - Product category
    * - Manufacturing date
    * - Expiry date
    * - Product price
    * @return true nếu sửa thành công, false nếu không có sản phẩm chứa code được nhập.
    */
    public boolean updateProduct(String code, String newName, String newCategory, LocalDate newManufactureDate, LocalDate newExpiryDate, Double newPrice) {
    Product product = products.get(code);
    if (product == null) return false;
    
    if (newName != null) product.setProductName(newName);
        
    if (newCategory != null) product.setCategory(newCategory);
        
    if (newManufactureDate != null) product.setManufacturingDate(newManufactureDate);

    if (newExpiryDate != null) product.setExpirationDate(newExpiryDate);

    if (newPrice != null) product.setPrice(newPrice);
    return true;
}
    
    /**
     * check sản phẩm đã tồn tại trong receips nào chưa
     * @param code sản phẩm để check
     * @return true nếu không có list receipts null 
     * @throws ProductNotFoundException 
     */
    public boolean deleteProductCheck(String code) throws ProductNotFoundException {
        WarehouseController warehouseController = new WarehouseController();
        List<Receipt> receipts = warehouseController.getReceiptsByProductCode(code);
        return !(receipts != null && !receipts.isEmpty());
    }
    
    /**
     * bỏ product có code đã được nhập ra khỏi hashmap chứa product
     * @param code của product sẽ xóa
     */
    public void deleteProduct(String code){
        products.remove(code);
    }

    public Product getProductByCode(String code) throws ProductNotFoundException {
    if (!products.containsKey(code)) {
        throw new ProductNotFoundException("Product with code " + code + " not found.");
    }
    return products.get(code);
}

    public List<Product> getAllProducts() {
    return new ArrayList<>(products.values());
}
   
    public boolean checkProductExists(String code) {
        return products.containsKey(code);
    }
    
    public boolean checkEmpty(){
        return products.isEmpty();
    }
    
    /**
     * tạo ra list các sản phẩm hết hạn dựa vào isExpired method 
     * @return list gồm các sản phẩm hết hạn
     * @throws ProductNotFoundException nếu không có sản phẩm nào thỏa điều kiện
     */
    public List<Product> getExpiredProducts() throws ProductNotFoundException {
        List<Product> expiredProducts = new ArrayList<>();
        for (Product product : products.values()) {
            if (product.isExpired()) {
                expiredProducts.add(product);
            }
        }
        if (expiredProducts.isEmpty()) {
            throw new ProductNotFoundException("No expired products found.");
        }
        return expiredProducts;
    }
    
    private void updateProductQuantities(Product product, int quantity) {
        product.setExportedQuantity(product.getExportedQuantity() + quantity);
        product.setImportedQuantity(product.getImportedQuantity() - quantity);
        System.out.println("Item added to export receipt and product quantity updated.");
    }
}
