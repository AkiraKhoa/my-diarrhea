package View;

import static Controller.DataController.loadDataOnStartup;
import Controller.ProductNotFoundException;
import java.io.FileNotFoundException;

public class Main {

    public static void main(String[] args) throws ProductNotFoundException, FileNotFoundException {

       
        MainView mainView = new MainView();
        loadDataOnStartup();
        
        mainView.showMenu();
    }
}
