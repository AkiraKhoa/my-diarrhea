
package Tools;
import Controller.ProductController;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.time.format.DateTimeFormatter;

public class Tool {
    private static Scanner scanner = new Scanner(System.in);
    
    /**
     * check người dùng nhập đúng category 
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @return 0 hoặc 1 hoặc null cho update
     */
    public static Integer validateCategoryInputUpdate(String prompt) {
    while (true) {
        System.out.print(prompt);
        String input = scanner.nextLine();

        if (input.isEmpty()) {
            return null;
        }

        if ("0".equals(input) || "1".equals(input)) {
            return Integer.parseInt(input);
        }

        System.out.println("Invalid category. Please enter 0 for daily or 1 for longshelf.");
    }
}
    
    //TAKE CODE, NAME, PRICE, QUANTITY INFO
    /**
     * check user nhập code chỉ có số và chữ
     * @param prompt thông báo user nhập thông tin cần thiết
     * @param errorMessage thông báo lỗi nếu không đúng pattern 
     * @return code đã được thông qua
     */
    public static String validateCode(String prompt, String errorMessage) {
        String input;
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (Pattern.matches("[a-zA-Z0-9]+", input)) {
                break;
            }
            System.out.println(errorMessage);
        }
        return input;
        }
    
    /**
     * check 1 int ko âm 
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param errorMessage khi sai format
     * @return int đã được thông qua
     */
    public static int validateInt(String prompt, String errorMessage) {
        int number;
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                number = Integer.parseInt(input);
                if (number > 0) {
                    break;
                } else {
                    System.out.println("Number should be greater than 0.");
                }
            } catch (NumberFormatException e) {
                System.out.println(errorMessage);
            }
        }
        return number;
    }
    
    //========================================================================================================
    /**
     * check user có nhập 1 số tồn tại trong 1 hashmap được cho hay không
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param errorMessage báo lỗi nếu không tồn tại
     * @return 
     */
    public static String validateExistProductInMap(String prompt, String errorMessage) {
        String input;
        ProductController productController = new ProductController();
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (productController.getProducts().containsKey(input)) {
                break;
            }
            System.out.println(errorMessage);
        }
        return input;
    }
    
    /**
     * check user nhập y hoặc n cho yes hoặc no
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @return true nếu input là y, false nếu bằng n
     */
    public static boolean validateYesOrNo(String prompt) {
        String input;
        while (true) {
            System.out.print(prompt + " (y/n): ");
            input = scanner.nextLine().trim().toLowerCase();
            if ("y".equals(input) || "n".equals(input)) {
                break;
            }
            System.out.println("Invalid input. Enter 'y' for yes and 'n' for no.");
        }
        return "y".equals(input);
    }
    
    /**
     * check user nhập số trong khoảng cho phép
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param min số nhỏ nhất được nhận
     * @param max số lớn nhất được nhận
     * @param errorMessage báo lỗi nhập số ngoài khoảng
     * @return int đã được thông qua
     */
    public static int validateIntRange(String prompt, int min, int max, String errorMessage) {
        int input;
        while (true) {
            System.out.print(prompt);
            try {
                input = Integer.parseInt(scanner.nextLine());
                if (input >= min && input <= max) {
                    return input;
                } else {
                    System.out.println(errorMessage);
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }
   
    /**
     * check user nhập chuỗi chỉ có số và chữ và dấu cách
     * @param prompt thông báo user nhập thông tin cần thiết
     * @param errorMessage thông báo lỗi nếu không đúng pattern 
     * @param allowEmpty được quyền để trống nếu true
     * @return chuỗi đã được thông qua
     */
    public static String validateAlphanumericString(String prompt, String errorMessage, boolean allowEmpty) {
        String input;
        while (true) {
            System.out.print(prompt);
            input = scanner.nextLine().trim();

            if (input.isEmpty() && allowEmpty) {
                return null;
            } else if (!input.isEmpty() && Pattern.matches("[a-zA-Z0-9 ]+", input)) {
                break;
            }
            System.out.println(errorMessage);
        }
        return input;
    }

    /**
     * check user nhập số thập phân không âm
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param formatErrorMessage báo nhập sai format
     * @param negativeErrorMessage báo nhập số âm
     * @param allowEmpty được quyền để trống nếu true
     * @return số thập phân đã được thông qua 
     */
    public static Double validateDouble(String prompt, String formatErrorMessage, String negativeErrorMessage, boolean allowEmpty) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            if (input.isEmpty() && allowEmpty) {
                return null;
            }

            try {
                double number = Double.parseDouble(input);
                if (number >= 0) {
                    return number;
                } else {
                    System.out.println(negativeErrorMessage);
                }
            } catch (NumberFormatException e) {
                System.out.println(formatErrorMessage);
            }
        }    
    }
    
    
    /**
     * check 1 date được nhập có đúng format không
     * @param prompt yêu cầu user nhập thông tin cần thiết
     * @param errorMessage báo lỗi
     * @param allowEmpty được quyền để trống nếu true
     * @return LocalDate được thông qua
     */
    public static LocalDate validateLocalDate(String prompt, String errorMessage, boolean allowEmpty) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            if (input.isEmpty() && allowEmpty) {
                return null;
            }

            try {
                return LocalDate.parse(input, formatter);
            } catch (DateTimeParseException e) {
                System.out.println(errorMessage);
            }
        }
    }
    
    /**
     * check ngày được nhập không quá thời gian hiện tại 
     * @param prompt yêu cầu người dùng nhập thông tin cần thiết
     * @param errorMessage báo lỗi
     * @param allowEmpty được quyền để trống nếu true
     * @return LocalDate đã được thông qua
     */
    public static LocalDate validateNotFutureDate(String prompt, String errorMessage, boolean allowEmpty) {
        LocalDate date;
        while (true) {
            date = validateLocalDate(prompt, "Invalid date format. Please enter again.", allowEmpty);
            if (date == null || !date.isAfter(LocalDate.now())) {
                return date;
            }
            System.out.println(errorMessage);
        }
    }
    
    /**
     * check ngày hết hạn nhập vào hợp lệ
     * @param prompt yêu cầu người dùng nhập thông tin cần thiết
     * @param afterThisDate ngày sản xuất được truyền vào
     * @param errorMessage báo lỗi
     * @param allowEmpty được quyền để trống nếu true
     * @return LocalDate đã được thông qua
     */
    public static LocalDate validateDateAfter(String prompt, LocalDate afterThisDate, String errorMessage, boolean allowEmpty) {
    LocalDate date;
    while (true) {
        date = validateLocalDate(prompt, "Invalid date format. Please enter again.", allowEmpty);
        if (date == null || date.isAfter(afterThisDate.plusDays(7))) {
            return date;
        }
        System.out.println(errorMessage);
    }
}



}
