package Controller;

import Data.DataSingleton;
import Model.ExportReceipt;
import Model.ImportReceipt;
import Model.Product;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Map;

public class DataController {
    public static Object loadDataFromFile(String filePath) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            return ois.readObject(); 
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading data: " + e.getMessage());
            return null;
        }
    }

    /**
    * Lưu data vào file 
    * @param filePath đường dẫn tới file được lưu
    * @param data data sẽ được lưu vào file
    */
    public static void saveDataToFile(String filePath, Object data) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(data); 
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }
    
    /**
    * Loads application data from files during startup and populates the DataSingleton instance.
    * Load data từ 2 file Product và Warehouse gồm:
    * hashmap products chứa Product.
    * hashmap importreceipts chứa import receipts.
    * hashmap exportreceipts chứa export receipts.
    */
    public static void loadDataOnStartup() {
        DataSingleton instance = DataSingleton.getInstance();

        Map<String, Product> products = (Map<String, Product>) loadDataFromFile("./Product.dat");
        if (products != null) {
            instance.getProducts().putAll(products);
        }

        Map<String, ImportReceipt> importReceipts = (Map<String, ImportReceipt>) loadDataFromFile("./Warehouse.dat");
        if (importReceipts != null) {
            instance.getImportReceipts().putAll(importReceipts);
        }

        Map<String, ExportReceipt> exportReceipts = (Map<String, ExportReceipt>) loadDataFromFile("./Warehouse.dat");
        if (exportReceipts != null) {
            instance.getExportReceipts().putAll(exportReceipts);
        }
    }
    
    /**
    * Stores all application data from the DataSingleton instance to respective files.
    * Lưu tất cả dữ liệu sau khi đã sửa đổi vào 2 file Product và Warehouse bao gồm:
    * hashmap products chứa Product.
    * hashmap importreceipts chứa import receipts.
    * hashmap exportreceipts chứa export receipts.
    * Lưu thành công sẽ có thông báo xác nhận
    * The method performs the following steps:
    */
    public static void storeAllData() {
        DataSingleton instance = DataSingleton.getInstance();

        saveDataToFile("./Product.dat", instance.getProducts());
        saveDataToFile("./Warehouse.dat", instance.getImportReceipts());
        saveDataToFile("./Warehouse.dat", instance.getExportReceipts());

        System.out.println("Data saved successfully!");
    }


}
