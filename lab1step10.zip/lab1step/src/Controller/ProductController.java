package Controller;

import Data.DataSingleton;
import Model.Product;
import Model.Receipt;
import Tools.Tool;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.time.LocalDate;



public class ProductController {
    private Map<String, Product> products;
    public ProductController() {
        this.products = DataSingleton.getInstance().getProducts();
    }
    
    public Map<String, Product> getProducts() {
        if (products == null) {
            products = DataSingleton.getInstance().getProducts();
        }
        return products;
    }


    /**
    * Thêm product vào hashmap products
    * @param category Loại sản phẩm "Daily" hoặc "L.shelf".
    * @return true nếu thêm thành công.
    */
    public void addProduct(String code, String name, String category, LocalDate manufactureDate, LocalDate expiryDate, double price) {
        products.put(code, new Product(code, name, category, manufactureDate, expiryDate, price));
        System.out.println("Product added successfully!");
    }
    
    /**
    * Set lại info của product.
    * Những info có thể sửa:
    * - Product name
    * - Product category
    * - Manufacturing date
    * - Expiry date
    * - Product price
    * @return true nếu sửa thành công, false nếu không có sản phẩm chứa code được nhập.
    */
    public void updateProduct(String code, String newName, String newCategory, LocalDate newManufactureDate, LocalDate newExpiryDate, Double newPrice) {
    Product product = products.get(code);
    
    if (newName != null) product.setProductName(newName);
        
    if (newCategory != null) product.setCategory(newCategory);
        
    if (newManufactureDate != null) product.setManufacturingDate(newManufactureDate);

    if (newExpiryDate != null) product.setExpirationDate(newExpiryDate);

    if (newPrice != null) product.setPrice(newPrice);
    System.out.println("Product updated successfully!");

}
    
    /**
     * check sản phẩm đã tồn tại trong receips nào chưa
     * @param code sản phẩm để check
     * @return true nếu không có list receipts null 
     * @throws ProductNotFoundException 
     */
    public boolean deleteProductCheck(String code) throws ProductNotFoundException {
        WarehouseController warehouseController = new WarehouseController();
        List<Receipt> receipts = warehouseController.getReceiptsByProductCode(code);
        return !(receipts != null && !receipts.isEmpty());
    }
    
    /**
     * bỏ product có code đã được nhập ra khỏi hashmap chứa product
     * @param code của product sẽ xóa
     */
    public void deleteProduct(String code){
        products.remove(code);
    }

    public Product getProductByCode(String code) throws ProductNotFoundException {
    if (!products.containsKey(code)) {
        throw new ProductNotFoundException("Product with code " + code + " not found.");
    }
    return products.get(code);
}

    public List<Product> getAllProducts() {
    return new ArrayList<>(products.values());
}
   
    public boolean checkProductExists(String code) {
        return products.containsKey(code);
    }
    
    public boolean checkEmpty(){
        return products.isEmpty();
    }
    
    /**
     * tạo ra list các sản phẩm hết hạn dựa vào isExpired method 
     * @return list gồm các sản phẩm hết hạn
     * @throws ProductNotFoundException nếu không có sản phẩm nào thỏa điều kiện
     */
    public List<Product> getExpiredProducts() throws ProductNotFoundException {
        List<Product> expiredProducts = new ArrayList<>();
        for (Product product : products.values()) {
            if (product.isExpired()) {
                expiredProducts.add(product);
            }
        }
        if (expiredProducts.isEmpty()) {
            throw new ProductNotFoundException("No expired products found.");
        }
        return expiredProducts;
    }
    
    /**
     * điều chỉnh số lượng mỗi khi export
     * @param product product sẽ được điều chỉnh số lượng
     * @param quantity số lượng product sẽ được điều chỉnh
     */
    public void updateProductQuantities(Product product, int quantity) {
        product.setExportedQuantity(product.getExportedQuantity() + quantity);
        product.setImportedQuantity(product.getImportedQuantity() - quantity);
        System.out.println("Item added to export receipt and product quantity updated.");
    }
    
    /**
     * nhập và cập nhật thông tin ngày hết hạn
     * @param category loại sản phẩm
     * @param newManufactureDate ngày sản xuất
     * @param currentProduct sản phẩm lúc chưa đổi
     * @return 
     */
    public LocalDate getUpdatedExpiryDate(String category, LocalDate newManufactureDate, Product currentProduct) {
    if (category.equals("Daily")) {
        return newManufactureDate.plusDays(1);
    } else {
        LocalDate tempExpiDate = currentProduct.getExpirationDate();
        if (tempExpiDate.isAfter(newManufactureDate.plusDays(7))) {
            LocalDate updatedExpiryDate = Tool.validateDateAfter("Enter expiry date (d/M/yyyy) or Enter skip this one: ", newManufactureDate, "Expiry date Lshelf must be after manufacturing date atleast 7d.", true);
            return (updatedExpiryDate == null) ? tempExpiDate : updatedExpiryDate;
        } else {
            return Tool.validateDateAfter("Enter expiry date (d/M/yyyy) can't skip this one: ", newManufactureDate, "Expiry date Lshelf must be after manufacturing date atleast 7d.", false);
        }
    }
}

    
    public LocalDate addExpiryDate(String category, LocalDate manufactureDate) {
        if (category.equals("Daily")) {
            return manufactureDate.plusDays(1);
        } else {
            return Tool.validateDateAfter("Enter expiry date (dd/mm/yyyy): ", manufactureDate, "Expiry date Lshelf must be after manufacturing date atleast 7d.", false);
        }
    }
}
