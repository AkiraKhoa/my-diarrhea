package Model;
import java.io.Serializable;
import java.util.*;

public class Receipt implements Serializable {
    private String receiptsCode; 
    private Date date; 
    private Map<String, Integer> receiptsItem; 
    
    public Receipt(String receiptsCode) {
        this.receiptsCode = receiptsCode;
        this.date = new Date(); 
        this.receiptsItem = new HashMap<>();
    }
    public boolean containsProduct(String productCode) {
        return receiptsItem.containsKey(productCode);
    }

    public String getReceiptsCode() {
        return receiptsCode;
    }

    public void setReceiptsCode(String receiptsCode) {
        this.receiptsCode = receiptsCode;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setReceiptsItem(Map<String, Integer> receiptsItem) {
        this.receiptsItem = receiptsItem;
    }

    public Map<String, Integer> getReceiptsItem() {
        return receiptsItem;
    }

    /**
     * thêm số lượng sản phẩm vào receipt
     * @param productCode sản phẩm sẽ được thêm số lượng
     * @param quantity số lượng sản phẩm được thêm vào 
     */
    public void addProductToReceipt(String productCode, int quantity) {
        if (receiptsItem.containsKey(productCode)) {
            int existingQuantity = receiptsItem.get(productCode);
            receiptsItem.put(productCode, existingQuantity + quantity);
        } else {
            receiptsItem.put(productCode, quantity);
        }
    }
    
    public String toString(String specialProductCode) {
        System.out.println("Receipt Code: " + receiptsCode);
        System.out.println("Creation Time: " + date);
        System.out.println("Products:");
        for (Map.Entry<String, Integer> entry : receiptsItem.entrySet()) {
            if (entry.getKey().equals(specialProductCode)) {
                System.out.println("======" + entry.getKey() + ": " + entry.getValue() + "======");
            } else {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
        }
        
        return ""; // 
    }

}
