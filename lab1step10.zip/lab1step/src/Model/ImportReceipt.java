
package Model;

public class ImportReceipt extends Receipt {
    public ImportReceipt(String code) {
        super(code);
    }
}
