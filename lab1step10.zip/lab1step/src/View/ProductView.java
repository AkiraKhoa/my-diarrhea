package View;

import Controller.ProductController;
import Controller.ProductNotFoundException;
import Model.Product;
import Tools.Tool;
import java.time.LocalDate;
import java.util.List;

public class ProductView {
    ProductController productController = new ProductController();

    public ProductView() {
    }
    
    public void start() throws ProductNotFoundException {
        while (true) {
            System.out.println("-----------------------------------------------------");
            System.out.println("                    Product Menu                     ");
            System.out.println("-----------------------------------------------------");
            System.out.println("1. Add New Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. List All Products");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int option = Tool.validateIntRange("Choose an option: ", 1, 5, "Invalid option. Try again.");

            switch (option) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    updateProduct();
                    break;
                case 3:
                    deleteProduct();
                    break;
                case 4:
                    displayAllProducts();
                    break;
                case 5:
                    return;
            }
        }
    }

    /**
     * hiển thị tất cả thông tin của product dựa vào hashmap products
     */
    public void displayAllProducts() {
    if (productController.checkEmpty()) return;
    List<Product> allProducts = productController.getAllProducts();

    System.out.println("List of all products:");
    System.out.println("+--------+--------+----------+------------+------------+------------+--------------+--------------+--------+");
    System.out.println("|  Code  |  Name  |Category  |Manufacture |  Expiry    | Price      |Imported Qty. |Exported Qty. |  Qty.  |");
    System.out.println("+--------+--------+----------+------------+------------+------------+--------------+--------------+--------+");

    for (Product product : allProducts) {
        System.out.println(product.toStringShowAll());
    }
        System.out.println("+--------+--------+----------+------------+------------+------------+--------------+--------------+--------+");
    }

    /**
    * Tương tâc hướng dẫn nhập info product sẽ thêm vào.
    * Tiếp tục tới khi nào ấn n.
    * Kiểm tra thông tin:
    * - product code is unique.
    * - product name is alphanumeric.
    * - product price >=0.
    * - ngày sản xuất không quá ngày hiện tại
    * - ngày hết hạn ổn dựa trên loại
    * nhập xong sẽ gọi add method bên controller để thêm product vào list.
    */
    public void addProduct() {
    while(true){
        String code = Tool.validateCode("Enter product code: ", "Invalid code. Only alphanumeric characters are allowed.");
    if (productController.checkProductExists(code)) {
        System.out.println("Product code already exists!");
        boolean decision = Tool.validateYesOrNo("Press Enter to exit or type 'y' to input another product code.");
        if (decision) continue;
        else return;
    }
    String name = Tool.validateAlphanumericString("Enter product name: ", "Name cannot be empty and don't have special characters", false);
    Double price = Tool.validateDouble("Enter product price: ", "What did you just type?", "You can't give customers money for buying something! :((( T.T T.T ", false);    

    int categoryChoice = Tool.validateIntRange("Choose product category (0 for Daily, 1 for Longshelf): ", 0, 1, "Invalid choice.");
    String category = categoryChoice == 0 ? "Daily" : "L.shelf";
        
    LocalDate manufactureDate = Tool.validateNotFutureDate("Enter manufacture date (dd/mm/yyyy): ", "Date cannot be in the future.", false);
    LocalDate expiryDate = productController.addExpiryDate(category, manufactureDate);
    
    productController.addProduct(code, name, category, manufactureDate, expiryDate, price);
    boolean confirm = Tool.validateYesOrNo("Would you like to add more products?");
        if (!confirm) {
            break;
        }
    }
}
    
    /**
     * Tương tâc hướng dẫn nhập info product sẽ sửa.
     * Cho phép người dùng enter để skip nhưng vẫn đảm bảo:
     * - The product code exists.
     * - The product name is alphanumeric.
     * - The product price >=0.
     * - Ngày sản xuất và hết hạn ổn dựa trên loại
     * nhập xong sẽ gọi update method bên controller để sửa info.
     * @throws ProductNotFoundException If the product code exists does not exist.
     */
    public void updateProduct() throws ProductNotFoundException {
    if (productController.checkEmpty()) return;
    String code = Tool.validateExistProductInMap("Enter the product code to update: ", "Product code does not exist!");
    Product currentProduct = productController.getProductByCode(code);
    
    String newName = Tool.validateAlphanumericString("Enter new productName or enter to skip: ", "Name cannot be empty and don't have special characters", true);
    Double newPrice = Tool.validateDouble("Enter new productPrice or enter to skip: ", "invalid number", "You can't give customers money for buying something! :((( T.T T.T ", true);
    Integer newCategory = Tool.validateCategoryInputUpdate("Enter category (0 for daily, 1 for longshelf or Enter to skip): ");
    if (newCategory == null) newCategory = currentProduct.getCategoryBinary();
    String category = newCategory == 0 ? "Daily" : "L.shelf";
    
    LocalDate newManufactureDate = Tool.validateNotFutureDate("Enter manufacturing date (d/M/yyyy) or Enter to skip: ", "Date cannot be in the future.", true);
    if (newManufactureDate == null) newManufactureDate = currentProduct.getManufacturingDate();
    LocalDate newExpiryDate = productController.getUpdatedExpiryDate(category, newManufactureDate, currentProduct);
    productController.updateProduct(code, newName, category, newManufactureDate, newExpiryDate, newPrice);
        currentProduct.toString();
    } 


    /**
     * User nhập code sản phẩm muốn xóa và đảm bảo muốn xóa 
     * kiểm tra:
     * - The product code exists.
     * - Sản phẩm chưa được tạo receipts
     */
    public void deleteProduct() throws ProductNotFoundException {
        if (productController.checkEmpty()) return;
        String code = Tool.validateExistProductInMap("Enter the product code to delete: ", "Product code does not exist!");
        
        if (!productController.deleteProductCheck(code)) {
                System.out.println("Cannot delete this product. Import/export information has been generated.");
                return;
            }
        
        boolean confirm = Tool.validateYesOrNo("Are you sure you want to delete this product?");
        if (!confirm) {
            System.out.println("Product deletion cancelled.");
            return;
        }
        productController.deleteProduct(code);
        System.out.println("Product deleted successfully!");
    }
}

