package View;

import Controller.ImportExportController;
import Controller.ProductController;
import Controller.ProductNotFoundException;
import Model.Product;
import Tools.Tool;


public class WarehouseView {
    ProductController productController = new ProductController();
    ImportExportController importExportController = new ImportExportController();
    
    
    public WarehouseView() {
    }

    public void start() throws ProductNotFoundException {
        while (true) {
            System.out.println("-----------------------------------------------------");
            System.out.println("                   Warehouse Menu                    ");
            System.out.println("-----------------------------------------------------");
            System.out.println("1. Manage Import Receipt");
            System.out.println("2. Manage Export Receipt");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            
            int option = Tool.validateIntRange("Choose an option: ", 1, 3, "Invalid option. Try again.");

            switch (option) {
                case 1:
                    createAndManageImportReceipt();
                    break;
                case 2:
                    createAndManageExportReceipt();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
    
    /**
    * Tương tác hướng dẫn người dùng tạo import receipts
    * các bước của method:
    * kiểm tra tồn tại products để import không.
    * tạo unique code cho receipt
    * thêm số lượng product dựa vào input của user và hỏi để tiếp tục thêm product khác
    * sau khi xong sẽ add receip vào hashmap chứa import receipts
    * @throws ProductNotFoundException If the product with the given code does not exist.
    */
    public void createAndManageImportReceipt() throws ProductNotFoundException {
        if (productController.checkEmpty()) return;
        String receiptCode = importExportController.createNewImportReceipt();
        
        while (true) {
            String productCode = Tool.validateExistProductInMap("Enter the product code to import: ", "Product code does not exist!");
            int quantity = Tool.validateInt("Enter the quantity: ", "Invalid quantity.");

            boolean itemAdded = importExportController.addItemToImportReceipt(receiptCode, productCode, quantity);
            if (itemAdded) {
                System.out.println("Item added to import receipt and product quantity updated.");
            } else {
                System.out.println("Failed to add item to import receipt.");
            }
            if (!Tool.validateYesOrNo("Would you like to import more products?")) {
                break;
            }
        }
        System.out.println("Import receipt confirmed.");
    } 
    
    
    /**
    * Tương tác hướng dẫn người dùng tạo export receipts
    * Các bước của method:
    * kiểm tra tồn tại products để export không.
    * tạo unique code cho receipt
    * thêm số lượng product dựa vào input của user và hỏi để tiếp tục thêm product khác
    * nếu không có sản phẩm được add vào sẽ xóa receipt 
    * sau khi xong sẽ add receip vào hashmap chứa export receipts
    * @throws ProductNotFoundException If the product with the given code does not exist.
    */
    public void createAndManageExportReceipt() throws ProductNotFoundException {
    if (productController.checkEmpty()) return;
    String receiptCode = importExportController.createNewExportReceipt();
    
    boolean itemAddedFlag = false; 

    while (true) {
        String productCode = Tool.validateExistProductInMap("Enter the product code to export: ", "Product code does not exist!");
        Product product = productController.getProductByCode(productCode);
        if (product.getImportedQuantity() == 0) {
            System.out.println("Warning: The imported quantity of this product is 0. You can't export it.");
            if (!Tool.validateYesOrNo("Would you like to export a different product?")) break;
            continue;
        }
                
        int quantity = Tool.validateInt("Enter the quantity: (Current imported quantity for product " + productCode + ": " + product.getImportedQuantity() + "): ","Invalid quantity.");
        if (product.getImportedQuantity() < quantity) {
            System.out.println("Export quantity exceeds available stock. Current imported quantity for product " + productCode + ": " + product.getImportedQuantity());
        } else {
            importExportController.addItemToExportReceipt(receiptCode, productCode, quantity);
            itemAddedFlag = true;
        }
        if (!Tool.validateYesOrNo("Would you like to export more products?")) {
            break;
        }
    }
        if (!itemAddedFlag) {
            importExportController.removeExportReceipt(receiptCode);
        } else {
            System.out.println("Export receipt confirmed.");
        }
    }
}
