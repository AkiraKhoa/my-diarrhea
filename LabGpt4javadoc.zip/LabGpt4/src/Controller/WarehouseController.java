package Controller;
import Data.DataSingleton;
import Model.ExportReceipt;
import Model.ImportReceipt;
import Model.Product;
import Model.Receipt;
import java.util.*;

public class WarehouseController {
    private Map<String, ImportReceipt> importReceipts;
    private Map<String, ExportReceipt> exportReceipts;
    private Map<String, Product> products;
    public WarehouseController() {
        this.importReceipts = DataSingleton.getInstance().getImportReceipts();
        this.exportReceipts = DataSingleton.getInstance().getExportReceipts();
        this.products = DataSingleton.getInstance().getProducts();
        
    }
    
    public List<Receipt> getReceiptsByProductCode(String productCode) throws ProductNotFoundException {
        if (productCode == null || productCode.isEmpty()) {
            throw new IllegalArgumentException("Invalid product code.");
        }
        List<Receipt> matchingReceipts = new ArrayList<>();
        for (Receipt receipt : importReceipts.values()) {
            if (receipt instanceof ImportReceipt && receipt.containsProduct(productCode)) {
                matchingReceipts.add(receipt);
            }
        }
        for (Receipt receipt : exportReceipts.values()) {
            if (receipt instanceof ExportReceipt && receipt.containsProduct(productCode)) {
                matchingReceipts.add(receipt);
            }
        }
        if (matchingReceipts.isEmpty()) {
            throw new ProductNotFoundException("No receipts found for product with code: " + productCode);
        }
        return matchingReceipts;
    }

    
    public void displayProductData(String productCode) throws ProductNotFoundException {
        if (!products.containsKey(productCode)) {
            System.out.println("Product does not exist");
            return;
        }

        Product product = products.get(productCode);
        System.out.println("Product Data from warehouse.dat or warehouse's collection:");
        System.out.println(product.toString());  // Assuming you've implemented a good toString() in Product

        List<Receipt> relatedReceipts = getReceiptsByProductCode(productCode);
        if (relatedReceipts.isEmpty()) {
            System.out.println("No import/export receipts for this product.");
        } else {
            System.out.println("Related Receipts:");
            for (Receipt receipt : relatedReceipts) {
                System.out.println(receipt.toString());  // Assuming you've implemented a good toString() in Receipt
            }
        }
    }
    
    public List<Product> getProductsForSale() {
        List<Product> productsForSale = new ArrayList<>();
        for (Product product : products.values()) {
            int stock = product.getImportedQuantity() + product.getExportedQuantity();
            if (!product.isExpired() && stock > 0) {
                productsForSale.add(product);
            }
        }
        return productsForSale;
    }
    
    public List<Product> getLowStockProducts() {
        List<Product> lowStockProducts = new ArrayList<>();
        for (Product product : products.values()) {
            int stock = product.getImportedQuantity() + product.getExportedQuantity();
            if (stock <= 3) {
                lowStockProducts.add(product);
            }
        }
        // Sort by quantity
        Collections.sort(lowStockProducts, Comparator.comparing(product -> 
            product.getImportedQuantity() + product.getExportedQuantity()));
        return lowStockProducts;
    }
    
}
    
    
    

