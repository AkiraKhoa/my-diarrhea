package Controller;

import Data.DataSingleton;
import Model.Product;
import Model.Receipt;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.time.LocalDate;
import java.util.Iterator;



public class ProductController {
    private Map<String, Product> products;
    private String pathFile;
    public ProductController() {
        this.products = DataSingleton.getInstance().getProducts();
        this.pathFile = "";
    }


    /**
    * Adds a new product to the product collection.
    * Thêm product vào hashmap products
    * @param category Loại sản phẩm "Daily" hoặc "L.shelf".
    * @return true if the product was added successfully, false if a product with the same code already exists.
    * @return true nếu thêm thành công.
    */
    public boolean addProduct(String code, String name, String category, LocalDate manufactureDate, LocalDate expiryDate, double price) {
        products.put(code, new Product(code, name, category, manufactureDate, expiryDate, price));
        return true;
    }
    
    /**
    * Set lại info của product.
    * <p>
    * Những info có thể update:
    * - Product name
    * - Product category
    * - Manufacturing date
    * - Expiry date
    * - Product price
    * </p>
    * @return true nếu sửa thành công, false nếu không có sản phẩm chứa code được nhập.
    */
    public boolean updateProduct(String code, String newName, String newCategory, LocalDate newManufactureDate, LocalDate newExpiryDate, double newPrice) {
        Product product = products.get(code);
        if (product == null) {
            return false;
        }
        product.setProductName(newName);
        product.setCategory(newCategory);
        product.setManufacturingDate(newManufactureDate);
        product.setExpirationDate(newExpiryDate);
        product.setPrice(newPrice);
        return true;
    }
    
    public boolean deleteProductCheck(String code) throws ProductNotFoundException {
        WarehouseController warehouseController = new WarehouseController();
        List<Receipt> receipts = warehouseController.getReceiptsByProductCode(code);
        return !(receipts != null && !receipts.isEmpty());
    }
    public void deleteProduct(String code){
        products.remove(code);
    }

    public Product getProductByCode(String code) throws ProductNotFoundException {
    if (!products.containsKey(code)) {
        throw new ProductNotFoundException("Product with code " + code + " not found.");
    }
    return products.get(code);
}

    public List<Product> getAllProducts() {
    return new ArrayList<>(products.values());
}
   
    public boolean checkProductExists(String code) {
        return products.containsKey(code);
    }

    public List<Product> getExpiredProducts() throws ProductNotFoundException {
        List<Product> expiredProducts = new ArrayList<>();
        for (Product product : products.values()) {
            if (product.isExpired()) {
                expiredProducts.add(product);
            }
        }
        if (expiredProducts.isEmpty()) {
            throw new ProductNotFoundException("No expired products found.");
        }
        return expiredProducts;
    }
}
