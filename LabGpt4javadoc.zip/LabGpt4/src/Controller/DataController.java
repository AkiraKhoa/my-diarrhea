package Controller;

import Data.DataSingleton;
import Model.ExportReceipt;
import Model.ImportReceipt;
import Model.Product;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Map;

public class DataController {
    public static Object loadDataFromFile(String filePath) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            return ois.readObject(); 
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading data: " + e.getMessage());
            return null;
        }
    }

    
    public static void saveDataToFile(String filePath, Object data) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(data); 
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }
    
    public static void loadDataOnStartup() {
        DataSingleton instance = DataSingleton.getInstance();

        Map<String, Product> products = (Map<String, Product>) loadDataFromFile("./Product.dat");
        if (products != null) {
            instance.getProducts().putAll(products);
        }

        Map<String, ImportReceipt> importReceipts = (Map<String, ImportReceipt>) loadDataFromFile("./Warehouse.dat");
        if (importReceipts != null) {
            instance.getImportReceipts().putAll(importReceipts);
        }

        Map<String, ExportReceipt> exportReceipts = (Map<String, ExportReceipt>) loadDataFromFile("./Warehouse.dat");
        if (exportReceipts != null) {
            instance.getExportReceipts().putAll(exportReceipts);
        }
    }
    
    public static void storeAllData() {
        DataSingleton instance = DataSingleton.getInstance();

        saveDataToFile("./Product.dat", instance.getProducts());
        saveDataToFile("./Warehouse.dat", instance.getImportReceipts());
        saveDataToFile("./Warehouse.dat", instance.getExportReceipts());

        System.out.println("Data saved successfully!");
    }


}
