package View;

import Controller.ProductController;
import Controller.ProductNotFoundException;
import Data.DataSingleton;
import Model.Product;
import Tools.Tool;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ProductView {
    private final Scanner scanner;
    ProductController productController = new ProductController();
    private Map<String, Product> products;
    DataSingleton loadPr = new DataSingleton();

    public ProductView() {
        this.scanner = new Scanner(System.in);
        this.products = DataSingleton.getInstance().getProducts();
    }
    
    public void start() throws ProductNotFoundException {
        while (true) {
            System.out.println("-----------------------------------------------------");
            System.out.println("                    Product Menu                     ");
            System.out.println("-----------------------------------------------------");
            System.out.println("1. Add New Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. List All Products");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int option = Tool.validateIntRange("Choose an option: ", 1, 5, "Invalid option. Try again.");

            switch (option) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    updateProduct();
                    break;
                case 3:
                    deleteProduct();
                    break;
                case 4:
                    displayAllProducts();
                    break;
                case 5:
                    return;
            }
        }
    }

    public void displayAllProducts() {
    List<Product> allProducts = productController.getAllProducts();
    if (allProducts.isEmpty()) {
        System.out.println("No products are available.");
        return;
    }

    System.out.println("List of all products:");
    System.out.println("+--------+--------+----------+------------+------------+------------+--------------+--------------+--------+");
    System.out.println("|  Code  |  Name  |Category  |Manufacture |  Expiry    | Price      |Imported Qty. |Exported Qty. |  Qty.  |");
    System.out.println("+--------+--------+----------+------------+------------+------------+--------------+--------------+--------+");

    for (Product product : allProducts) {
        System.out.println(product.toStringShowAll());
    }
        System.out.println("+--------+--------+----------+------------+------------+------------+--------------+--------------+--------+");
    }

    /**
    * Tương tâc hướng dẫn nhập info product sẽ thêm vào.
    * Tiếp tục tới khi nào ấn n.
    * <p>
    * Kiểm tra thông tin:
    * - product code is unique.
    * - product name is alphanumeric.
    * - product price >=0.
    * - The manufacture date is not in the future.
    * - The expiry date is valid based on the product category.
    * </p>
    * nhập xong sẽ gọi add method bên controller để thêm product vào list.
    */
    public void addProduct() {
    while(true){
        String code = Tool.validateCode("Enter product code: ", "Invalid code. Only alphanumeric characters are allowed.");
    if (productController.checkProductExists(code)) {
        System.out.println("Product code already exists!, Failed to add product");
        return;
    }

    String name = Tool.validateAlphanumericString("Enter product name: ", "Name cannot be empty and don't have special characters");
    double price = Tool.validateDouble("Enter product price: ", "What did you just type?", "You can't give customers money for buying something! :((( T.T T.T ");    

    int categoryChoice = Tool.validateIntRange("Choose product category (0 for Daily, 1 for Longshelf): ", 0, 1, "Invalid choice.");
    String category = categoryChoice == 0 ? "Daily" : "L.shelf";
        
    LocalDate manufactureDate;
    LocalDate expiryDate;
    
    if (category.equals("Daily")) {
        manufactureDate = Tool.validateNotFutureDate("Enter manufacture date (dd/mm/yyyy): ", "Date cannot be in the future.");
        expiryDate = manufactureDate.plusDays(1);
    } else {
        manufactureDate = Tool.validateNotFutureDate("Enter manufacture date (dd/mm/yyyy): ", "Date cannot be in the future.");
        expiryDate = Tool.validateDateAfter("Enter expiry date (dd/mm/yyyy): ", manufactureDate, "Expiry date Lshelf must be after manufacturing date atleast 7d.");
    }
    productController.addProduct(code, name, category, manufactureDate, expiryDate, price);
    System.out.println("Product added successfully!");
    boolean confirm = Tool.validateYesOrNo("Would you like to add more products?");
        if (!confirm) {
            break;
        }
    }
}
    
    /**
     * Tương tâc hướng dẫn nhập info product sẽ sửa.
     * <p>
     * Cho phép người dùng enter để skip nhưng vẫn đảm bảo:
     * - The product code exists.
     * - The product name is alphanumeric.
     * - The product price is valid.
     * - The manufacture and expiry dates are valid based on the product category.
     * </p>
     * nhập xong sẽ gọi update method bên controller để sửa info.
     * @throws ProductNotFoundException If the product code exists does not exist.
     */
    public void updateProduct() throws ProductNotFoundException {;
    if (products.isEmpty()) {
        System.out.println("There are no products to update!");
        return;
    }
    String code = Tool.validateExistInMap("Enter the product code to update: ", products, "Product code does not exist!");
    Product currentProduct = productController.getProductByCode(code);
    String newName = Tool.validateAlphanumericStringUpdate("Enter new productName or enter to skip: ", "Name cannot be empty and don't have special characters");
    if (newName==null) newName=currentProduct.getProductName();
    Double newPrice = Tool.validateDoubleUpdate("Enter new productPrice or enter to skip: ", "invalid number", "You can't give customers money for buying something! :((( T.T T.T ");
    if (newPrice==null) newPrice=currentProduct.getPrice();
    Integer newCategory = Tool.validateCategoryInput("Enter category (0 for daily, 1 for longshelf or Enter to skip): ");
    if (newCategory == null) {
        newCategory = currentProduct.getCategoryBinary(); 
    }
    LocalDate newManufactureDate = null;
    LocalDate newExpiryDate = null;
    LocalDate tempManuDate=currentProduct.getManufacturingDate();
    LocalDate tempExpiDate=currentProduct.getExpirationDate();
    if (newCategory == 0) {
        newManufactureDate = Tool.validateManufacturingDate("Enter manufacturing date (d/M/yyyy) or Enter to skip: ");
        if (newManufactureDate == null) newManufactureDate = tempManuDate;
        newExpiryDate = newManufactureDate.plusDays(1);
    }
    if (newCategory == 1){
        newManufactureDate = Tool.validateManufacturingDate("Enter manufacturing date (d/M/yyyy) or Enter to skip: ");
        if (newManufactureDate == null) newManufactureDate = tempManuDate;
        if (tempExpiDate.isAfter(newManufactureDate.plusDays(7))) {
            newExpiryDate = Tool.validateExpiryForLongShelfSkip("Enter expiry date (d/M/yyyy) or Enter skip this one: ", newManufactureDate);
            if (newExpiryDate == null) newExpiryDate = tempExpiDate;
        }
        else newExpiryDate = Tool.validateExpiryForLongShelf("Enter expiry date (d/M/yyyy) can't skip this one: ", newManufactureDate);
    }
    String newCategory1 = null;
    if (newCategory == 0) newCategory1="Daily";
    if (newCategory == 1) newCategory1="L.shelf";
    if (!productController.updateProduct(code, newName, newCategory1, newManufactureDate, newExpiryDate, newPrice)) {
        System.out.println("Product does not exist!");
        return;
    }
    System.out.println("Product updated successfully!");
    currentProduct.toString();
    }

    
    public void deleteProduct() {
        if (products.isEmpty()) {
            System.out.println("There are no products to update!");
            return;
        }
        String code = Tool.validateExistInMap("Enter the product code to delete: ", products, "Product code does not exist!");
        try {
            if (!productController.deleteProductCheck(code)) {
                System.out.println("Cannot delete this product. Import/export information has been generated.");
                return;
            }
        } catch (ProductNotFoundException e) {
            System.out.println("Product not found!");
            return;
        }
        boolean confirm = Tool.validateYesOrNo("Are you sure you want to delete this product?");
        if (!confirm) {
            System.out.println("Product deletion cancelled.");
            return;
        }
        productController.deleteProduct(code);
        System.out.println("Product deleted successfully!");
    }
}

